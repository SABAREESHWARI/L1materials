//package Junit;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class SearchBoxExcelGrid {
	
	public static void main(String[] args) throws InterruptedException, MalformedURLException, IOException 

	{
		System.setProperty("webdriver.chromedriver.driver", "D:/chromedriver.exe");
	
		   
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setBrowserName("chrome");
		capabilities.setCapability("webdriver.chromedriver.driver", "D:/chromedriver.exe");
		

		
		capabilities.setPlatform(Platform.WINDOWS);
		//capabilities.setVersion(version);
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
		File src=new File("D://Harsha Vardhan//PLP//testdata.xlsx");
		FileInputStream fis = new FileInputStream(src);		
		
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheetAt(0);
		System.setProperty("webdriver.chrome.driver", "D:/chromedriver.exe");
		
		try
		{
		//WebDriver driver = new ChromeDriver();
		driver.get("https://demo.opencart.com");
		System.out.println("Website is being opened.\n");
		driver.manage().window().maximize();
	
		
		for(int i=1;i<=6;i++)
		{
			System.out.println("\nSearch "+i);
			WebElement search = driver.findElement(By.name("search"));
			String input = sheet.getRow(i).getCell(1).getStringCellValue();
			search.sendKeys(input);
			
			String check = search.getAttribute("value");
			
			//System.out.println(check);
			driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
			
			int len = check.length();
			String name = check.toLowerCase();
			//boolean spl = Pattern.compile("[^\\w\\s]").matcher(name).find();
			
			String products = driver.getPageSource();
			/*if(products.contains("mac"))
				System.out.println("Done");*/
			if(len==0)
			{
				System.out.println("This a required field. Fill it out.");
				//return false;
				//Thread.sleep(2000);
			}
			else if(products.contains("apple"))//Pattern.matches("[..apple..]{20}",name))
				{
					System.out.println("These are the apple products available");
					driver.navigate().to("https://demo.opencart.com/index.php?route=product/search&search=apple");
					driver.findElement(By.xpath(".//*[@id='content']/div[3]/div/div/div[2]/div[2]/button[1]")).click();
					System.out.println("Product is added to cart\n");
					Thread.sleep(2000);
					driver.findElement(By.xpath(".//*[@id='cart']/button"));
				}
				else if(products.contains("mac"))//Pattern.matches("[^mac]*6{20}", name))
				{
					Thread.sleep(2000);
					System.out.println("These are the mac products");
					driver.navigate().to("https://demo.opencart.com/index.php?route=product/search&search=mac");
					driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
					System.out.println("Product is added to cart\n");
					Thread.sleep(2000);
					driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
					//driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[2]/strong")).click();
				}
					else if(products.contains("iphone"))//Pattern.matches("[^iphone]{20}",name))
					{
					System.out.println("These are the iphones available");
					driver.navigate().to("https://demo.opencart.com/index.php?route=product/search&search=iphone");
					driver.findElement(By.xpath(".//*[@id='content']/div[3]/div/div/div[2]/div[2]/button[1]")).click();
					System.out.println("Product is added to cart\n");
					Thread.sleep(2000);
					driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
					}
					else if(products.contains("nikon"))//Pattern.matches("[^canon]{20}",name))
					{
						System.out.println("These are the nikon products");
						driver.navigate().to("https://demo.opencart.com/index.php?route=product/search&search=nikon");
						driver.findElement(By.xpath(".//*[@id='content']/div[3]/div/div/div[2]/div[2]/button[1]")).click();
						driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
						System.out.println("Product is added to cart\n");
						Thread.sleep(2000);
						driver.findElement(By.cssSelector(".btn.btn-inverse.btn-block.btn-lg.dropdown-toggle")).click();
						
					}
						
							else //if(spl)
							{
								System.out.println("Search for relevant content");
	
							}
			
			driver.navigate().to("https://demo.opencart.com");
			
		}
		driver.findElement(By.xpath(".//*[@id='top-links']/ul/li[5]/a/span")).click();
		System.out.println("\nChech-out now.");
		driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[2]/a")).click();
		
		//driver.close();
		
		}
		catch(Exception ex){
			System.out.println("Hello");
		}
}
}